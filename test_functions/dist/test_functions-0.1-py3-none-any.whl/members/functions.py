def multi (x,y):
    return(x*y)